**# Project Description**

Asma Ahmed developed this project, a website that analyzes articles by just supplying their URLs. Important statistics including agreement, polarity, and confidence are produced by the analysis. The webpack-server, custom scripts, and a range of webpack rules and plugins are just a few of the features that are included in the project.

**# how to run the News Article Analyzer - Asma Ahmed ?**

1-node -v
npm -v
2- npm install --force
3-(npm run build-dev) ==> run the development mode
3-(npm run build-prod) ==> run the production mode
5-(npm run start) ==> run the server
6-(npm run test) ==> run the test .
