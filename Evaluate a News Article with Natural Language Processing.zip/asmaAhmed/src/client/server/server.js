const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fetch = require('node-fetch');
require('dotenv').config();
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('dist'));

const apiKey = process.env.API_KEY;

app.post('/evaluate', async (req, res) => {
  const { url } = req.body;
  const apiUrl = `https://api.meaningcloud.com/sentiment-2.1?key=${apiKey}&url=${url}&lang=en`;

  
  try {
    const response = await fetch(apiUrl);
    const data = await response.json();
    res.send(data);
  } catch (error) {
    res.status(500).send({ error: 'Error fetching API data' });
  }
});

app.listen(8080, () => console.log('Server running on http://localhost:8080'));
