import { apiCall } from './apiCall.js';
async function handleSubmit(event) {
  event.preventDefault();

  const url = document.getElementById('url').value;
  if (!url) {
    alert('Please enter a valid URL');
    return;
  }

  try {
    const data = await apiCall(url);

    if (data) {
      document.getElementById('agreement').innerHTML = `${data.agreement || 'Not available'}`;
      document.getElementById("polarity").innerHTML = `${data.score_tag || 'Not available'}`;
      document.getElementById("confidence").innerHTML = ` ${data.confidence || 'Not available'}`;
    }
    else {
      alert('Failed to fetch results. Please try again.');
    }
  } catch (error) {
    console.error('Error handling submission:', error);
    alert('An error occurred while processing your request.');
  }
}

export { handleSubmit };
