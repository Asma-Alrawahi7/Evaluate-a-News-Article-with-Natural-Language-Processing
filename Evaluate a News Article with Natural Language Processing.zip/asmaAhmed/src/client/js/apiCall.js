export async function apiCall(url) {
  try {
    const response = await fetch('/evaluate', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error making API call:', error);
  }
}