import { apiCall } from '../src/client/js/apiCall';

// Mock global fetch
global.fetch = jest.fn();

describe('apiCall', () => {
  afterEach(() => {
    fetch.mockClear(); 
  });

  it('should return data when API call is successful', async () => {
    const mockResponse = { success: true, message: 'Data fetched' };

    fetch.mockResolvedValueOnce({
      json: jest.fn().mockResolvedValueOnce(mockResponse),
    });

    const result = await apiCall('https://example.com');

    expect(fetch).toHaveBeenCalledWith('/evaluate', expect.objectContaining({
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: 'https://example.com' }),
    }));
    expect(result).toEqual(mockResponse);
  });

  it('should handle errors and log them', async () => {
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation();

    fetch.mockRejectedValueOnce(new Error('API Error'));

    await apiCall('https://example.com');

    expect(consoleSpy).toHaveBeenCalledWith('Error making API call:', expect.any(Error));

    consoleSpy.mockRestore();
  });
});