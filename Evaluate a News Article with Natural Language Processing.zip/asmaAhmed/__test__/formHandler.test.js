import { handleSubmit } from '../src/client/js/formHandler';

test('handleSubmit should be defined', () => {
  expect(handleSubmit).toBeDefined();
});
